const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      
      on('before:browser:launch', (browser = {}, launchOptions) => {
        if (browser.family === 'chrome') { //Check if browser is Chrome
          // Add Chrome command line arguments to disable password manager prompts
          launchOptions.args.push('--disable-password-manager-reauthentication');
          launchOptions.args.push('--disable-save-password-bubble');

          // Disable web security to handle insecure HTTPS
          launchOptions.args.push('--ignore-certificate-errors');
          launchOptions.args.push('--allow-insecure-localhost');
          launchOptions.args.push('--disable-web-security');
          return launchOptions;
        }
      });
    },
    chromeWebSecurity: false,
    baseUrl: 'https://www.saucedemo.com'
  },
});
