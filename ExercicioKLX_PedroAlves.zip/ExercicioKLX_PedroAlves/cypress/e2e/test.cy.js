/// <reference types="cypress" />

describe('Sauce Demo Tests', () => {
  before(() => {
    // Intercept API requests to mocked endpoints
    cy.interceptApiRequests();
  });

  beforeEach(() => {
    // Perform login with a standard user
    cy.uiLogin('standard_user');
  });

  it('should log in, add products to cart, and complete purchase', () => {
    // Verify the inventory page loaded
    cy.url().should('include', '/inventory.html');
    cy.get('[data-test="inventory-list"]').should('be.visible'); // Ensure the inventory list is visible

    // Add specific products to the cart
    cy.get('[data-test="add-to-cart-sauce-labs-bike-light"]').should('be.visible').click();
    cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').should('be.visible').click();

    // Click on the cart icon to view the cart
    cy.get('[data-test="shopping-cart-link"]').should('be.visible').click();

    // Verify the cart page URL
    cy.url().should('include', '/cart.html');

    // Verify that the specific products were added to the cart
    cy.get('[data-test="inventory-item-name"]').should('contain.text', 'Sauce Labs Bike Light');
    cy.get('[data-test="inventory-item-name"]').should('contain.text', 'Test.allTheThings() T-Shirt (Red)');

    // Complete the purchase
    cy.completePurchase();
  });
});