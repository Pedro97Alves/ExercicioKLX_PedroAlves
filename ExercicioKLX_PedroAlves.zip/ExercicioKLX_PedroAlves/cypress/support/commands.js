// cypress/support/commands.js

// Import the intercept function from Cypress
Cypress.Commands.add('interceptApiRequests', () => {
  // Intercept POST requests to the summed-events endpoint and respond with a success message
  cy.intercept('POST', 'https://events.backtrace.io/api/summed-events/submit*', {
    statusCode: 200,
    body: { success: true },
  }).as('summedEvents'); // Alias this intercept as 'summedEvents'
  
  // Intercept POST requests to the unique-events endpoint and respond with a success message
  cy.intercept('POST', 'https://events.backtrace.io/api/unique-events/submit*', {
    statusCode: 200,
    body: { success: true },
  }).as('uniqueEvents'); // Alias this intercept as 'uniqueEvents'
});

// Command to log in using data from a fixture
Cypress.Commands.add('uiLogin', (userType) => {
  // Load user data from the fixture file
  cy.fixture('users').then((users) => {
    const user = users[userType];

    cy.visit('/'); // Use baseUrl defined in cypress.config.js
    cy.get('input[data-test="username"]').should('be.visible').type(user.username); // Type the username
    cy.get('input[data-test="password"]').should('be.visible').type(user.password); // Type the password
    cy.get('input[data-test="login-button"]').should('be.visible').click(); // Click the login button

    // Verify successful login by checking the URL
    cy.url().should('include', '/inventory.html');
  });
});

//Command to make checkout of purchase
Cypress.Commands.add('completePurchase', () => {
  cy.get('[data-test="checkout"]').click(); // Click checkout
  cy.get('[data-test="firstName"]').type('Pedro'); // Enter first name
  cy.get('[data-test="lastName"]').type('Alves'); // Enter last name
  cy.get('[data-test="postalCode"]').type('2890'); // Enter postal code
  cy.get('[data-test="continue"]').click(); // Continue
  cy.get('[data-test="finish"]').click(); // Finish purchase

  // Verify the purchase completion
  cy.get('[data-test="complete-header"]').should('contain', 'Thank you for your order');
});